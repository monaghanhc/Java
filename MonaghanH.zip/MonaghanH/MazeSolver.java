/*
THIS CODE WAS OUR OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING
CODE WRITTEN BY OTHER STUDENTS OR COPIED FROM ONLINE RESOURCES.
Hunter Monaghan
HW4, CSCI221-01, Spring 2021
The purpose of this code is to learn about a pathfinding algorithm that gets through a maze with 0's as the path and 1's and the wall. Enter/Exit
*/

import java.util.Stack;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileInputStream;

public class MazeSolver {

  static char[][] maze;
  static int startX, startY;  // indices for starting the maze search
  static int endX, endY; // indices for ending the maze search

  // Constructor that creates the maze
  public MazeSolver(String fileName) throws IOException {
    startX = 0;
    startY = 0;
    readMaze(fileName); // initialize maze
  }

  // Helper method for reading the maze content from a file
  public static void readMaze(String filename) throws IOException {
    Scanner scanner;
    try{
      scanner = new Scanner(new FileInputStream(filename));
    }
    catch(IOException ex){
      System.err.println("[ERROR] Invalid filename: " + filename);
      return;
    }

    int N = scanner.nextInt();
    scanner.nextLine();
    maze = new char[N][N];
    endX = N-1; endY = N-1;
    int i = 0;
    while(i < N && scanner.hasNext()) {
      String line =  scanner.nextLine();
      String [] tokens = line.split("\\s+");
      int j = 0;
      for (; j < tokens.length; j++){
        maze[i][j] = tokens[j].charAt(0);
      }
      if(j != N){
        System.err.println("[ERROR] Invalid line: " + i + " has wrong # columns: " + j);
        return;
      }
      i++;
    }
    if(i != N){
      System.err.println("[ERROR] Invalid file: has wrong number of rows: " + i);
      return;
    }
  }

  // Helper method for printing the maze in a matrix format
  public void printMaze() {
     for (int i=0; i < maze.length; i++) {
         for (int j=0; j < maze.length; j++) {
           System.out.print(maze[i][j]);
           System.out.print(' ');
          }
          System.out.println();
     }
  }

  // TODO: Solve the maze stored in the 2D-array "maze" object using a Stack.
  // If your algorithm finds a valid path out of the maze, print a success
  // message: "Maze is solvable." Otherwise, print: "Maze is NOT solvable."
  // Mark the valid positions you visited during your maze walk with an 'X' character.
  public void solveMaze(char [] [] maze) {

        //Stack<String> pathFinding = new Stack();
        Stack pathFinding = new Stack();//new object called pathFinding
        MazePosition begin = new MazePosition(startX, startY);
        MazePosition myPosition;

        int i = 0; 
        int j = 0;
        //push (0,0) onto stack
        pathFinding.push(begin);
        while(!pathFinding.isEmpty()){
          myPosition = (MazePosition)pathFinding.pop();
          j = myPosition.getX();
          i = myPosition.getY();
          maze[i][j] = 'X'; // Mark with an X
            // looking for left
            if (j != startX && maze[i][j-1] == '0') {//use switch/case or if?
              pathFinding.push(new MazePosition ((j - 1), i));
              //pathFind.push(new MazePosition ((j + 1), j));
            }
            // looking for right
            if (j != endX && maze[i][j + 1] == '0') {
              pathFinding.push(new MazePosition ((j + 1), i));
            }
            // looking for Down
            if (i != endY && maze[i+1][j] == '0') {
              pathFinding.push(new MazePosition (j, (i + 1)));
            }
            if (i != startY && maze[i-1][j] == '0') 
            {
              pathFinding.push(new MazePosition (j, (i - 1)));
              //pathFind.push(new MazePosition (j, (i + 1)));
            }
            //Prints Maze is Solvable with new line
            if (j == endX && i == endY) {
              System.out.print("Maze is Solvable. \n");
              break;
            }
        }
        //Prints maze is not solvable with new line
        if (j != endX || i != endY) {
          System.out.print("Maze is not Solvable. \n" );
        }
}


  public static void main(String[] args) throws IOException {
    // If no argument is provided, show error message
    if(args.length < 1) {
      System.err.println("[ERROR] Usage: java PathFinder maze_file");
      System.exit(-1);
    }
    // File name is provided properly as the first argument
    String fileName =  args[0];

    MazeSolver ms = new MazeSolver(fileName);
    System.out.println("[Before Traversal] Maze:");
    ms.printMaze();
    System.out.println();

    // Test solver
    ms.solveMaze(ms.maze);
    System.out.println();
    System.out.println("[After Traversal] Maze:");
    ms.printMaze();
  }

}
